import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _fcf89776 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "" */))
const _7be04277 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "" */))
const _9047dda4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "" */))
const _52232284 = () => interopDefault(import('..\\pages\\index\\details.vue' /* webpackChunkName: "" */))
const _9f31f57a = () => interopDefault(import('..\\pages\\index\\msg.vue' /* webpackChunkName: "" */))
const _053aed90 = () => interopDefault(import('..\\pages\\index\\personCenter.vue' /* webpackChunkName: "" */))
const _6615076c = () => interopDefault(import('..\\pages\\index\\personCenter\\index.vue' /* webpackChunkName: "" */))
const _6af839e1 = () => interopDefault(import('..\\pages\\index\\personCenter\\income.vue' /* webpackChunkName: "" */))
const _3fc340ea = () => interopDefault(import('..\\pages\\index\\personCenter\\mine.vue' /* webpackChunkName: "" */))
const _4e8fc664 = () => interopDefault(import('..\\pages\\index\\post.vue' /* webpackChunkName: "" */))
const _3f3e1856 = () => interopDefault(import('..\\pages\\index\\search.vue' /* webpackChunkName: "" */))
const _49d9a49a = () => interopDefault(import('..\\pages\\index\\_categoryId.vue' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/login",
    component: _fcf89776,
    name: "login"
  }, {
    path: "/register",
    component: _7be04277,
    name: "register"
  }, {
    path: "/",
    component: _9047dda4,
    name: "index",
    children: [{
      path: "details",
      component: _52232284,
      name: "index-details"
    }, {
      path: "msg",
      component: _9f31f57a,
      meta: {"requireAuth":true},
      name: "index-msg"
    }, {
      path: "personCenter",
      component: _053aed90,
      meta: {"requireAuth":true},
      children: [{
        path: "",
        component: _6615076c,
        meta: {"requireAuth":true},
        name: "index-personCenter"
      }, {
        path: "income",
        component: _6af839e1,
        meta: {"requireAuth":true},
        name: "index-personCenter-income"
      }, {
        path: "mine",
        component: _3fc340ea,
        meta: {"requireAuth":true},
        name: "index-personCenter-mine"
      }]
    }, {
      path: "post",
      component: _4e8fc664,
      meta: {"requireAuth":true},
      name: "index-post"
    }, {
      path: "search",
      component: _3f3e1856,
      name: "index-search"
    }, {
      path: ":categoryId?",
      component: _49d9a49a,
      name: "index-categoryId"
    }]
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
